=====
Utils
=====

.. module:: ScraperFC.utils

.. autofunction:: ScraperFC.utils.botasaurus_get.botasaurus_get

.. autofunction:: ScraperFC.utils.get_proxy.get_proxy

.. autofunction:: ScraperFC.utils.xpath_soup.xpath_soup