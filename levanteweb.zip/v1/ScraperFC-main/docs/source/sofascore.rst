=========
Sofascore
=========

.. automodule:: ScraperFC.sofascore
   :members:
   :undoc-members:
   :show-inheritance:
