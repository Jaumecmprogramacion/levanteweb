.. ScraperFC documentation master file, created by
   sphinx-quickstart on Tue Aug 30 20:39:34 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

=====================================
Welcome to ScraperFC's documentation!
=====================================

.. image:: ./images/ScraperFC-Logo-Final-2023-10-11\ copy-Full-Color.svg

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   getting_started.rst
   code_examples.rst
   apidocumentation.rst
   contributing.rst
   year_parameter.rst

==================
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
