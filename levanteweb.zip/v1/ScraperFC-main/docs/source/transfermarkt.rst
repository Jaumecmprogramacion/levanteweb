=============
Transfermarkt
=============

.. automodule:: ScraperFC.transfermarkt
   :members:
   :undoc-members:
   :show-inheritance:
