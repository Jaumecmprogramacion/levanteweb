=======
ClubElo
=======

.. automodule:: ScraperFC.clubelo
   :members:
   :undoc-members:
   :show-inheritance:
