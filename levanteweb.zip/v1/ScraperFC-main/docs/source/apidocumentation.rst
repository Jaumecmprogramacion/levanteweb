=================
API Documentation
=================

.. toctree::
   :maxdepth: 1
   :caption: Modules:

   capology.rst
   clubelo.rst
   fbref.rst
   fivethirtyeight.rst
   sofascore.rst
   transfermarkt.rst
   understat.rst
   utils.rst
