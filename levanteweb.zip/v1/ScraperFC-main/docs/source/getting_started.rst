===============
Getting Started
===============

Installing ScaperFC is easy! Just go ahead and run ``pip install ScraperFC`` from the command line 
and you should be good to go!

To see examples of how to use ScraperFC, please see :ref:`code-examples-reference`.

And if you still have questions please join our `Discord <https://discord.com/invite/C5N8dqCJAq>`_ 
or email me directly at osmour043@gmail.com.
