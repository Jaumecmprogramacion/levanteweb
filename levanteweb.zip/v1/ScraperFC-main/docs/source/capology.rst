========
Capology
========

.. automodule:: ScraperFC.capology
   :members:
   :undoc-members:
   :show-inheritance:
