=============
Code Examples
=============

The formatting on the cell outputs isn't always the best. If you zoom out, you can see the full 
output. Sorry about that, but I haven't been able to find a way to make it look better.

.. _code-examples-reference:
.. toctree::
   :maxdepth: 1
   :caption: Code Examples:

   example <example.ipynb>