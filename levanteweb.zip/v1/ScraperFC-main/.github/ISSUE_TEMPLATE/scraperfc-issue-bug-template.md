---
name: ScraperFC Issue Template
about: Issue template for ScraperFC bugs.
title: ''
labels: ''
assignees: ''

---

Module (e.g. FBRef, Understat, etc.): 

Description of problem:

Code:

Error message:
