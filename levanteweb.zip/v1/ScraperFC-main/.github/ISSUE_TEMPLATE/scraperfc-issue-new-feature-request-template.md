---
name: ScraperFC Issue Template
about: Issue template for new ScraperFC feature requests.
title: ''
labels: ''
assignees: ''

---

Module (e.g. FBRef, Understat, etc.): 

Feature request:
