declare module 'simple-react-lightbox';
declare module 'svg-loaders-react'